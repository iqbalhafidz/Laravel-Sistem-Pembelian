

<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card"> 
                <div class="card-body">
                    <a href="<?php echo e(route('unggul.create')); ?>" class=" btn-priamry btn-sm">
                        <button class="btn btn-primary btn-sm" >Tambah</button>
                    </a>
                    <br><br>
                    
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">x</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>                       
                    <?php endif; ?>

                    <div class="table-responsive" >
                        <table id="zero_config" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <td>NO</td>
                                    <td>Keunggulan</td>
                                    <td>AKSI</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <Td><?php echo e($item+1); ?></Td>
                                        <Td><?php echo $value->keunggulan; ?></Td>
                                        <Td>
                                            
                                            <a href="<?php echo e(route('unggul.edit', $value->id)); ?>" class=" btn-priamry btn-sm">
                                                <button class="btn btn-primary btn-sm" >Ubah</button>
                                            </a>|

                                            <form action="<?php echo e(route('unggul.destroy', $value->id)); ?>"  method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button class="btn btn-danger btn-sm">Hapus</button>

                                            </form> |

                                        </Td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                   
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>








<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iqbal\PROJECT\jasco\resources\views/admin/unggul/unggulindex.blade.php ENDPATH**/ ?>