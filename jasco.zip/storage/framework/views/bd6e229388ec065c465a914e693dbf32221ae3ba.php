

<?php $__env->startSection('content'); ?>

<div class="card">
        <div class="card-header">
            <strong>Tambah Keunggulan</strong>
        </div>
        <div class="card-body card-block">
            <form action="<?php echo e(route('unggul.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                                <div class="form-group">
                    <label for="Keunggulan" class="form-control-label">Deskripsi Keunggulan</label>
                    <textarea name="keunggulan" class="ckeditor form-control <?php $__errorArgs = ['keunggulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('keunggulan')); ?></textarea>
                    
                    <?php $__errorArgs = ['Keunggulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-muted"><?php echo e($message); ?></div>
                        
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
               
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-block">Tambah Keunggulan</button>
                </div>

            </form>
        </> 
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="//cdn.ckeditor.com/4.14.0/full/ckeditor.js"></script>
<script>
    
    var konten = document.getElementById("konten");
        CKEDITOR.replace(konten,{
        language:'en-gb'
    });
    CKEDITOR.config.allowedContent = true;

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iqbal\PROJECT\jasco\resources\views/admin/unggul/unggulcreate.blade.php ENDPATH**/ ?>