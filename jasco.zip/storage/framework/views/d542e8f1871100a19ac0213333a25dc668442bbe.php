
<?php $__env->startSection('conten'); ?>


    <main id="main">

        <!-- ======= Clients Section ======= -->
        <section id="clients" class="clients">
        <div class="container">

            

            <br><br>

        </div>
        </section><!-- End Clients Section -->
        
        <!-- ======= Portfolio Section ======= -->
        <section id="portfolio" class="portfolio">
        <div class="container">

            <div class="section-title" data-aos="fade-left">
            <h2>Produk</h2>
            
            </div>

            <div class="row" data-aos="fade-up" data-aos-delay="100">
            <div class="col-lg-12 d-flex justify-content-center">
                <ul id="portfolio-flters">
                <li data-filter="*" class="filter-active">All</li>
                <li data-filter=".filter-app">Jasco</li>
                <li data-filter=".filter-card">Baju Anak</li>
                <li data-filter=".filter-web">Baju Wanita</li>
                </ul>
            </div>
            </div>

            <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

                <?php if($data['pd']->count()>0): ?>
                <?php $__currentLoopData = $data['pd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                
                
                    <div class="col-lg-4 col-md-6 portfolio-item filter-app" >
                        <div class="portfolio-wrap" >
                            <img src="<?php echo e($item->foto); ?>" class="img-fluid" class="img-thumbnail" alt="" style="width:400px" style="height: 350px">
                                <div class="portfolio-info">
                                
                                <div class="portfolio-links">
                                    <a href="<?php echo e($item->foto); ?>" data-gall="portfolioGallery" class="venobox" title="App 1"><i class="bx bx-plus"></i></a>
                                    
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <h3 class="card-title"><?php echo e($item->nama); ?></h3>
                            <h6 class="card-text"><?php echo $item->keterangan; ?></h6>
                            <div class="product-price">
                                <h5>Rp. <?php echo e($item->harga); ?>  
                                <span style="text-decoration: line-through;" style="text-align: center">Rp. <?php echo e($item->diskon); ?></span> </h5>
                            </div>
                        </div>

                    </div>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>

                <div class="col-lg-12 d-flex justify-content-center">
                    <h5> Tidak Ada Produk</h5>
                </div>


                <?php endif; ?>

                

                        

                
                </div>

           
           
           
             <div class="d-flex justify-content-center"> <?php echo e($data['pd']->links()); ?> </div>
            

        </div>
        
        </section><!-- End Portfolio Section -->

        <!-- ======= About Section ======= -->
        <section id="about" class="about">
        <div class="container">

            <div class="row content">
                <div class="col-lg-6">
                    <div class="section-title" data-aos="fade-right">
                    <h2>Keunggulan</h2>
                    <p>.</p>
                    </div>
                </div>

             

            <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left" data-aos-delay="200">


                <?php if($data['unggulan']->count()>0): ?>
                <?php $__currentLoopData = $data['unggulan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                
                
                    
                                                
                            <p class="card-text"><?php echo $item->keunggulan; ?></p>
                            

                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>


                <div class="col-lg-12 d-flex justify-content-center">
                    <h5> Keunggulan Belum Diisi</h5>
                </div>

                <?php endif; ?>
                    
                    
                    
                
            </div>
            </div>

        </div>
        </section><!-- End About Section -->


        <!-- ======= Counts Section ======= -->
        <section id="counts" class="counts">
        <div class="container">

            <div class="row counters">

            

            <br>

            </div>

        </div>
        </section><!-- End Counts Section -->


        <!-- ======= Testimonials Section ======= -->
        <section id="testimonials" class="testimonials section-bg">
        <div class="container">

            <div class="row">
            <div class="col-lg-4">
                <div class="section-title" data-aos="fade-right">
                <h2>Testimoni</h2>
                <p>.</p>
                </div>
            </div>
            <div class="col-lg-8" data-aos="fade-up" data-aos-delay="100">
                <div class="owl-carousel testimonials-carousel">

                    <?php if($data['testi']->count()>0): ?>
                <?php $__currentLoopData = $data['testi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                
                
                    
                                                
                        <div class="testimonial-item">
                        <img src="<?php echo e($item->gambar); ?>" class="testimonial-img" alt="">
                        <p>
                            <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                            <?php echo $item->keterangan; ?>

                            <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                        </p>

                        
                    </div>

                            

                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>


                <div class="col-lg-12 d-flex justify-content-center">
                    <h5> Testimoni Belum ditambahkan</h5>
                </div>

                <?php endif; ?>

                </div>
            </div>
            </div>

        </div>
        </section><!-- End Testimonials Section -->

        

        


        <!-- ======= Team Section ======= -->
        <section id="team" class="team">
        <div class="container">

            <div class="row">
                <div class="col-lg-4">
                    <div class="section-title" data-aos="fade-right">
                    <h2>Bukti Transfer</h2>
                    <p>.</p>
                    </div>
                </div>

                <div class="col-lg-8" data-aos="fade-up" data-aos-delay="100">
                <div class="owl-carousel testimonials-carousel">

                    <?php if($data['transfer']->count()>0): ?>
                <?php $__currentLoopData = $data['transfer']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                
                
                    
                                                
                        <div class="team-item">
                        <img src="<?php echo e($item->gambar); ?>" class="team-img" alt="">
                        <p>
                            
                        </p>

                        
                    </div>

                            

                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>


                <div class="col-lg-12 d-flex justify-content-center">
                    <h5> Bukti Transfer Belum ditambahkan</h5>
                </div>

                <?php endif; ?>
            
                
            </div>

        </div>
        </section><!-- End Team Section -->


        


        <!-- ======= Clients Section ======= -->
        <section id="clients2" class="clients2">
        <div class="container">
            <div class="section-title" data-aos="fade-right" data-aos="zoom-in">
                <br><br><br>

                <h2>Pemesanan</h2>
                <p> Untuk Pemesanan Jasko dan Informasi Jasko. Bisa Hubungi WhatsApp dibawah ini</p>

                <?php $__currentLoopData = $data['info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($item->hp); ?>" class="btn-get-started scrollto">Chat WhatsApp klik disini</a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

                <br><br><br>

            

        </div>
        </section><!-- End Clients Section -->

<!-- ======= Counts Section ======= -->
        <section id="counts" class="counts">
        <div class="container">

            <div class="row counters">

            

            <br>

            </div>

        </div>
        </section><!-- End Counts Section -->


        

        

                

        

    </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iqbal\PROJECT\jasco\resources\views/front/home.blade.php ENDPATH**/ ?>