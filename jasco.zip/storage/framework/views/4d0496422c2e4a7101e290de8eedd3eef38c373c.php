

<?php $__env->startSection('content'); ?>

<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h4 class="page-title">Informasi</h4>
            <div class="ml-auto text-right">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"> <a href="<?php echo e(url('/')); ?>">Home</a> </li>
                        <li class="breadcrumb-item active" aria-current="page">Informasi</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Informasi</h5>
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">x</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>                       
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="zero_config" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <td>NO</td>
                                    <td>Judul </td>
                                    <td>Tag Line</td>
                                    
                                    <td>Alamat</td>
                                    <td>Telepon</td>
                                    <td>Handphone</td>
                                    <td>Email</td>
                                    <td>Facebook</td>
                                    <td>Instagram</td>
                                    <td>AKSI</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <Td><?php echo e($item+1); ?></Td>
                                        <Td><?php echo e($value->judul); ?></Td>
                                        <Td><?php echo e($value->tagline); ?></Td>
                                        
                                        <Td><?php echo $value->alamat; ?></Td>
                                        <Td><?php echo e($value->tlpn); ?></Td>
                                        <Td><?php echo e($value->hp); ?></Td>
                                        <Td><?php echo e($value->email); ?></Td>
                                        <Td><?php echo e($value->linkfb); ?></Td>
                                        <Td><?php echo e($value->linkig); ?></Td>
                                        <Td>
                                            <a href="<?php echo e(route('info.edit', $value->id)); ?>" class=" btn-priamry btn-sm">
                                                <button class="btn btn-primary btn-sm" >Ubah</button>
                                            </a>
                                        </Td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                   
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iqbal\PROJECT\jasco\resources\views/admin/info/infoindex.blade.php ENDPATH**/ ?>