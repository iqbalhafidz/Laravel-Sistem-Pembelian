<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transfer extends Model
{
    //
    protected $table ="Transfer";

    protected $fillable =[
        'gambar','keterangan'
    ];
}
